class BookersController < ApplicationController
  def index
    @bookers = Book.all
    @book = Book.new
  end

  def top
  end

  def show
  end

  def new
  end

  def create
    @book= Book.new(book_params)
    book.save
    redirect_to bookers_path
  end

  def edit
    @list = List.find(params[:id])
  end

  def update
    list = List.find(params[:id])
    list.update(list_params)
    redirect_to todolist_path(list.id)
  end

  private
  def book_params
    params.require(:book).permit(:title, :body)
  end
end
